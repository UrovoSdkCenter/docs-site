package com.zicox.btscanprintdemo;

import android.net.LocalSocket;
import android.net.LocalSocketAddress;
import android.util.Log;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;

public class Printer {
    private final static String TAG = "btscanprintdemo";
    public enum PrinterErrorType {
        PRINTER_OK,
        PRINTER_COVER_OPEN,
        PRINTER_NO_PAPER,
        PRINTER_PAPER_ERROR,
        PRINTER_UNKOWN_ERROR,
    }
    private static LocalSocket client =null;
    public Printer(){
    }
    public boolean open(){
        client = new LocalSocket();
        try {
            client.connect(new LocalSocketAddress("PrinterLocalServerSocket"));
            return true;
        } catch (IOException e) {
            Log.d(TAG,"Printer open:"+e.toString());
            e.printStackTrace();
        }
        return false;
    }
    public void close(){
        try {
            if(client!=null)client.close();
            client=null;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void flush(){
        try {
            while (client.getInputStream().available()>0){
                byte[] data=new byte[4096];
                int readlen=client.getInputStream().available();
                if(readlen>data.length)readlen=data.length;
                client.getInputStream().read(data,0,readlen);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public boolean write(byte[] data,int len){
        try {
            client.getOutputStream().write(data,0,len);
            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }
    public boolean write(String str){
        try {
            byte[] data=str.getBytes("GBK");
            write(data,data.length);
            return true;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return false;
    }
    public int read(byte[] data,int offset,int readlen,int timeout_ms){
        int readed=0;
        long t=System.currentTimeMillis();
        try {client.setSoTimeout(100);} catch (IOException e) {e.printStackTrace();}
        while(true){
            int len=0;
            try {len=client.getInputStream().read(data,offset+readed,readlen-readed);} catch (IOException e) {}
            if(len>0){
                readed+=len;
                if(readed>=readlen)break;
            }
            if(System.currentTimeMillis()-t>timeout_ms)break;
        }
        return readed;
    }
    public PrinterErrorType status(){
        byte[] req=new byte[]{0x1D,(byte)0x99};
        byte[] rsp=new byte[4];
        write(req,2);
        int rsp_len=read(rsp,0,4,1000);
        Log.d(TAG,"rsp_len:"+rsp_len);
        if(rsp_len!=4)return PrinterErrorType.PRINTER_UNKOWN_ERROR;
        if(rsp[0]!=0x1D&&rsp[1]!=0x99)return PrinterErrorType.PRINTER_UNKOWN_ERROR;
        if((rsp[2]&0x01)!=0)return PrinterErrorType.PRINTER_NO_PAPER;
        if((rsp[2]&0x02)!=0)return PrinterErrorType.PRINTER_COVER_OPEN;
        if((rsp[2]&0x40)!=0)return PrinterErrorType.PRINTER_PAPER_ERROR;
        return PrinterErrorType.PRINTER_OK;
    }
    public boolean rfid_write(int bank,int password,int offset,byte[] data,int len)
    {
        if(offset<4)offset=4;
        offset=(offset/2)*2;
        len=(len/2)*2;
        byte[] req=new byte[16+len];
        byte[] rsp=new byte[6];
        req[0]=0x1F;
        req[1]=(byte)0xBB;
        req[2]=(byte)(12+len);
        req[3]=0;
        req[4]=0x02;
        req[5]=0;
        req[6]=0;
        req[7]=(byte)((password>>0)&0xFF);
        req[8]=(byte)((password>>8)&0xFF);
        req[9]=(byte)((password>>16)&0xFF);
        req[10]=(byte)((password>>24)&0xFF);
        req[11]=(byte)bank;
        req[12]=(byte)((offset>>0)&0xFF);
        req[13]=(byte)((offset>>8)&0xFF);
        req[14]=(byte)((len>>0)&0xFF);
        req[15]=(byte)((len>>8)&0xFF);
        //Log.d(TAG, byteToHex(data,len));
        System.arraycopy(data,0,req,16,len);
        //Log.d(TAG, byteToHex(req,16+len));
        write(req,16+len);
        int readed=read(rsp,0,6,2000);
        if(readed!=6)return false;
        //Log.d(TAG, byteToHex(rsp,6));
        if(rsp[0]!=0x1F||rsp[1]!=(byte)0xBB||rsp[2]!=0x02||rsp[3]!=0x00||rsp[4]!=(byte)0x82)return false;
        if(rsp[5]!=0x00)return false;
        return true;
    }
    public boolean rfid_read(int bank,int password,int offset,byte[] data,int len)
    {
        if(offset<4)offset=4;
        offset=(offset/2)*2;
        len=(len/2)*2;
        byte[] req=new byte[16];
        byte[] rsp=new byte[7];
        req[0]=0x1F;
        req[1]=(byte)0xBB;
        req[2]=(byte)(12);
        req[3]=0;
        req[4]=0x03;
        req[5]=0;
        req[6]=0;
        req[7]=(byte)((password>>0)&0xFF);
        req[8]=(byte)((password>>8)&0xFF);
        req[9]=(byte)((password>>16)&0xFF);
        req[10]=(byte)((password>>24)&0xFF);
        req[11]=(byte)bank;
        req[12]=(byte)((offset>>0)&0xFF);
        req[13]=(byte)((offset>>8)&0xFF);
        req[14]=(byte)((len>>0)&0xFF);
        req[15]=(byte)((len>>8)&0xFF);
        write(req,16);
        int readed=read(rsp,0,7,2000);
        if(readed!=7)return false;
        if(rsp[0]!=0x1F||rsp[1]!=(byte)0xBB||rsp[4]!=(byte)0x83)return false;
        int epc_len=rsp[5]+(rsp[6]<<8);
        if(epc_len>0){
            byte[] epc_data=new byte[epc_len];
            readed=read(epc_data,0,epc_len,2000);
            if(readed!=epc_len)return false;
        }
        readed=read(rsp,0,2,2000);
        if(readed!=2)return false;
        int rsp_data_len=rsp[0]+(rsp[1]<<8);
        if(rsp_data_len!=len)return false;
        readed=read(data,0,len,2000);
        if(readed!=len)return false;
        return true;
    }
    public static String byteToHex(byte[] bytes, int cnt){
        String strHex = "";
        StringBuilder sb = new StringBuilder("");
        for (int n = 0; n < cnt; n++) {
            strHex = Integer.toHexString(bytes[n] & 0xFF);
            sb.append((strHex.length() == 1) ? "0" + strHex : strHex);
        }
        return sb.toString().trim();
    }

    public boolean setReadPower(int vlaue) {
        byte[] req=new byte[8];
        byte[] rsp=new byte[8];
        req[0]=0x1F;
        req[1]=(byte)0xBB;
        req[2]=(byte)(4);
        req[3]=0;
        req[4]=0x04;
        req[5]=(byte)0xFF;
        req[6]=(byte)((vlaue>>0)&0xFF);
        req[7]=(byte)((vlaue>>8)&0xFF);
        write(req,req.length);
        int readed=read(rsp,0,8,2000);
        if(readed!=8) return false;
        if(rsp[0]!=(byte)0x1F||rsp[1]!=(byte)0xBB||rsp[4]!=(byte)0x84)return false;
        if(rsp[6]==(byte)0xFF&&rsp[7]==(byte)0x7F)return false;
        int readValue=rsp[6]+(rsp[7]<<8);
        if(vlaue!=readValue) return  false;
        return true;
    }

    public int getReadPower() {
        byte[] req=new byte[8];
        byte[] rsp=new byte[8];
        req[0]=0x1F;
        req[1]=(byte)0xBB;
        req[2]=(byte)(4);
        req[3]=0;
        req[4]=0x04;
        req[5]=(byte)0xFF;
        req[6]=(byte)((0x7FFF>>0)&0xFF);
        req[7]=(byte)((0x7FFF>>8)&0xFF);
        write(req,req.length);
        int readed=read(rsp,0,rsp.length,2000);
        if(readed!=rsp.length) return 0x7FFF;
        if(rsp[0]!=(byte)0x1F||rsp[1]!=(byte)0xBB||rsp[4]!=(byte)0x84) return 0x7FFF;
        int readValue=rsp[6]+(rsp[7]<<8);

        return readValue;
    }

    public boolean setWritePower(int vlaue) {
        byte[] req=new byte[8];
        byte[] rsp=new byte[8];
        req[0]=0x1F;
        req[1]=(byte)0xBB;
        req[2]=(byte)(4);
        req[3]=0;
        req[4]=0x05;
        req[5]=(byte)0xFF;
        req[6]=(byte)((vlaue>>0)&0xFF);
        req[7]=(byte)((vlaue>>8)&0xFF);
        write(req,req.length);
        int readed=read(rsp,0,rsp.length,2000);
        if(readed!=rsp.length) return false;
        if(rsp[0]!=(byte)0x1F||rsp[1]!=(byte)0xBB||rsp[4]!=(byte)0x85)return false;
        if(rsp[6]==(byte)0xFF&&rsp[7]==(byte)0x7F)return false;
        int readValue=rsp[6]+(rsp[7]<<8);
        if(vlaue!=readValue) return  false;
        return true;
    }

    public int getWritePower() {
        byte[] req=new byte[8];
        byte[] rsp=new byte[8];
        req[0]=0x1F;
        req[1]=(byte)0xBB;
        req[2]=(byte)(4);
        req[3]=0;
        req[4]=0x05;
        req[5]=(byte)0xFF;
        req[6]=(byte)((0x7FFF>>0)&0xFF);
        req[7]=(byte)((0x7FFF>>8)&0xFF);
        write(req,req.length);
        int readed=read(rsp,0,rsp.length,2000);
        if(readed!=rsp.length) return 0x7FFF;
        if(rsp[0]!=(byte)0x1F||rsp[1]!=(byte)0xBB||rsp[4]!=(byte)0x85) return 0x7FFF;
        int readValue=rsp[6]+(rsp[7]<<8);

        return readValue;
    }

    public int getCurLabelPower(){
        byte[] req=new byte[5];
        byte[] head=new byte[6];
        byte[] label = new byte[4];
        req[0]=0x1F;
        req[1]=(byte)0xBB;
        req[2]=(byte)(1);
        req[3]=0;
        req[4]=0x01;
        write(req,req.length);
        if(read(head,0,head.length,2000)!=head.length) return 0x7FFF;
        if(head[0]!=(byte)0x1F||head[1]!=(byte)0xBB||head[4]!=(byte)0x81) return 0x7FFF;
        int number = head[5];
        if(number <= 0) return 0x6FFF;
        int maxLabelPower = Integer.MIN_VALUE;
        for (int i=0;i<number;i++){
            if(read(label,0,label.length,2000) !=label.length)return  0x7FFF;
            byte []epc = new byte[label[2]+(label[3]<<8)];
            if(read(epc,0,epc.length,2000) !=epc.length)return  0x7FFF;
            if(maxLabelPower < label[1])maxLabelPower = label[1];
        }
        return maxLabelPower;
    }
}
