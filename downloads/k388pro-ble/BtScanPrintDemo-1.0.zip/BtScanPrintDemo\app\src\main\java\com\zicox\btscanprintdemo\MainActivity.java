package com.zicox.btscanprintdemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private final static String TAG = "btscanprintdemo";
    private Context context;
    private static final int BLUETOOTH_PERMISSION_REQUEST_CODE = 1;
    private Printer printer=new Printer();
    private TextView textDeviceName;
    private EditText editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG,"onCreate");
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            getSupportActionBar().setTitle(getString(R.string.app_name)+" "+info.versionName);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        setContentView(R.layout.activity_main);
        context = this;
        checkBluetoothPermission();
        textDeviceName=findViewById(R.id.btDeviceName);
        editText=findViewById(R.id.editText);
        editText.requestFocus();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(getString(R.string.quit)).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem item) {
                BtScanPrintService.stop_service(context);
                finish();
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }
    public void startBtScanPrintService(Context context){
        BtScanPrintService.start_service(context, new BtScanPrintService.ConnectionChangeCallBack() {
            @Override
            public void callback(String deviceAddr, String deviceName, boolean conntect) {
                Log.d(TAG,"BtScanPrintService.ConnectionChangeCallBack");
                textDeviceName.setText(conntect?deviceName:"");
            }
        }, new BtScanPrintService.ScanDataCallBack() {
            @Override
            public void callback(String deviceAddr, String deviceName, String scan_data) {
                Log.d(TAG,"BtScanPrintService.ScanDataCallBack");
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try{
                            editText.setText(scan_data);
                        }catch(Exception e){
                            editText.setText(scan_data);
                        }
                        printLabel(scan_data);
                        try {Thread.sleep(100);} catch (InterruptedException e) {}
                        editText.setText("");
                    }
                }).start();
            }
        });
    }
    private void checkBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                    != PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG,"ActivityCompat.requestPermissions");
                ActivityCompat.requestPermissions(
                        this,
                        new String[]{Manifest.permission.BLUETOOTH_CONNECT},
                        BLUETOOTH_PERMISSION_REQUEST_CODE
                );
            } else {
                // 权限已授予，执行蓝牙操作
                Log.d(TAG,"checkBluetoothPermission permission granted");
                startBtScanPrintService(this);
            }
        } else {
            // Android 12 以下版本不需要动态请求
            Log.d(TAG,"checkBluetoothPermission <12 not need permission granted>");
            startBtScanPrintService(this);
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == BLUETOOTH_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG,"onRequestPermissionsResult>");
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                startBtScanPrintService(this);
            } else {
                // 权限被拒绝
            }
        }
    }
    protected void hideInput(){
        InputMethodManager imm=(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
        View v=getWindow().peekDecorView();
        if(null!=v)imm.hideSoftInputFromWindow(v.getWindowToken(),0);
    }
    private boolean detectPrinterStatus(){
        Printer.PrinterErrorType status=printer.status();
        if(status!=Printer.PrinterErrorType.PRINTER_OK){
            printer.close();
            String errorMsg="打印机未知错误";
            if(status==Printer.PrinterErrorType.PRINTER_NO_PAPER)errorMsg="打印机缺纸";
            if(status==Printer.PrinterErrorType.PRINTER_COVER_OPEN)errorMsg="打印机纸仓盖未合上";
            if(status==Printer.PrinterErrorType.PRINTER_PAPER_ERROR)errorMsg="打印机纸张残留";
            return false;
        }
        return true;
    }
    protected void printLabel(String value){
        printer.open();
        printer.flush();
        //if(!detectPrinterStatus()){printer.close();return;}
        String prnData=PrnDataStr.cpcl;
        prnData=prnData.replace("<BARCODE>",value);
        Log.d(TAG,"prnData:["+prnData+"]");
        printer.write(prnData);
        printer.close();
    }
}