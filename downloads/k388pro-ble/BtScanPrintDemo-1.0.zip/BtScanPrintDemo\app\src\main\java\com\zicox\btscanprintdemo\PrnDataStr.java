package com.zicox.btscanprintdemo;

public class PrnDataStr {
    static String cpcl=
                "! 0 200 200 260 1\n"+
                "CENTER\n"+
                "B 128 2 1 80 0 50 <BARCODE>\n"+
                "T 0 32 0 150 <BARCODE>\n"+
                "GAP-SENSE\n"+
                "FORM\n"+
                "PRINT\n";
    static String zpl=
            "^XA\n"+
            "^PW380\n"+
            "^LL203\n"+
            "^LH20,10\n"+
            "^FX Top section with logo, name and address.\n"+
            "^A@N,160,60,8D^FO50,15^FDJ^FS\n"+
            "^A@N,90,35,8D^FO150,10^FD29.1X^FS\n"+
            "^A@N,24,24^FO175,100^FDDRIVER^FS\n"+
            "^A@N,24,24^FO210,125^FDAID^FS\n"+
            "^A@N,70,30,8D^FO250,100^FR^FD373^FS\n"+
            "^A@N,22,22^FO10,130^FDTBA315189537438^FS\n"+
            "^XZ\n"+
            "";
}
