package com.zicox.btscanprintdemo;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.Intent;
import android.net.LocalServerSocket;
import android.net.LocalSocket;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresPermission;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class BtScanPrintService extends Service {
    private final static String TAG = "btscanprintdemo";
    private Context service=null;
    private String notificationId = "ChannelId"+TAG;
    private String notificationName = "ChannelName"+TAG;
    private Notification.Builder builder;
    private LocalServerSocket localServerSocket=null;
    private LocalSocket localSocket=null;
    public interface ConnectionChangeCallBack{
        public abstract void callback(String deviceAddr,String deviceName,boolean conntect);
    }
    private static ConnectionChangeCallBack _ConnectionChangeCallBack=null;
    public interface ScanDataCallBack{
        public abstract void callback(String deviceAddr,String deviceName,String scan_data);
    }
    private static ScanDataCallBack _ScanDataCallBack=null;
    private BluetoothDevice bleDevice=null;
    private BluetoothGatt bluetoothGatt=null;
    private BluetoothGattCharacteristic scannerRxCharacteristic=null;
    private BluetoothGattCharacteristic txCharacteristic=null;
    private BluetoothGattCharacteristic rxCharacteristic=null;
    private int mtu_size=20;
    public BtScanPrintService() {
        Log.d(TAG,"BtScanPrintService");
    }
    private void createNotification(){
        NotificationManager notificationManager = (NotificationManager) this.getSystemService(this.NOTIFICATION_SERVICE);
        NotificationChannel channel = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            channel = new NotificationChannel(notificationId, notificationName, NotificationManager.IMPORTANCE_LOW);
            channel.setLockscreenVisibility(Notification.VISIBILITY_SECRET);
            channel.enableLights(false);
            channel.enableVibration(false);
            channel.setSound(null, null);
            notificationManager.createNotificationChannel(channel);
            builder = new Notification.Builder(this,notificationId);
        }
        Intent intent = new Intent(this,MainActivity.class);
        PendingIntent pendingIntent=null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);
        } else {
            pendingIntent = PendingIntent.getActivity(this,0,intent, PendingIntent.FLAG_IMMUTABLE);
        }
        builder.setContentIntent(pendingIntent);
    }
    public void show_disconnected()
    {
        builder.setSmallIcon(R.drawable.printer_disconnected);
        startForeground(2,builder.build());
    }
    public void show_connected()
    {
        builder.setSmallIcon(R.drawable.printer_service);
        startForeground(2,builder.build());
    }
    @Override
    public void onCreate() { // 创建服务
        super.onCreate();
        Log.d(TAG,"BtScanPrintService onCreate");
        service=this;
        createNotification();
        show_disconnected();
        initLocalServerSocket();
        taskFindBtDevice();
    }
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Log.d(TAG,"BtScanPrintService onBind");
        return null;
    }
    @Override
    public int onStartCommand(Intent intent, int flags, int startid) { // 启动服务，Android2.0以上使用
        Log.d(TAG,"BtScanPrintService onStartCommand");
        super.onStartCommand(intent, flags, startid);
        return START_STICKY;
    }
    @Override
    public void onDestroy() { // 销毁服务
        Log.d(TAG,"BtScanPrintService onDestroy");
        stopForeground(true);
        super.onDestroy();
    }
    @Override
    public void onRebind(Intent intent) { // 重新绑定服务
        Log.d(TAG,"BtScanPrintService onRebind");
        super.onRebind(intent);
    }
    @Override
    public boolean onUnbind(Intent intent) { // 解绑服务
        Log.d(TAG,"BtScanPrintService onUnbind");
        return true;
    }
    public static void start_service(Context context,ConnectionChangeCallBack mConnectionChangeCallBack,ScanDataCallBack mScanDataCallBack){
        _ConnectionChangeCallBack=mConnectionChangeCallBack;
        _ScanDataCallBack=mScanDataCallBack;
        //start service
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Log.d(TAG,"startForegroundService");
            context.startForegroundService(new Intent(context, BtScanPrintService.class));
        }else{
            context.startService(new Intent(context, BtScanPrintService.class));
        }
    }
    public static void stop_service(Context context){
        Intent serviceIntent = new Intent(context, BtScanPrintService.class);
        context.stopService(serviceIntent);
    }
    private void initLocalServerSocket(){
        try {
            Log.d(TAG,"localServerSocket create");
            localServerSocket=new LocalServerSocket("PrinterLocalServerSocket");
        } catch (IOException e) {
            Log.d(TAG,"localServerSocket create fail");
        }
        new ServerThread().start();
    }
    private class ServerThread extends Thread {
        @Override
        public void run(){
            try {
                while (true){
                    localSocket=localServerSocket.accept();
                    new BtScanPrintService.ServerRxThread(localSocket).start();
                }
            } catch (IOException e) {
            }
        }
    }
    private class ServerRxThread extends Thread {
        private LocalSocket socket;
        public ServerRxThread(LocalSocket localSocket){
            socket=localSocket;
        }
        @Override
        public void run() {
            byte[] data=new byte[65536];
            while(true){
                int len=0;
                try {
                    len=socket.getInputStream().read(data);
                } catch (IOException e) {
                }
                if(len>0){
                    localSocket=socket;
                    byte[] txData=new byte[len];
                    System.arraycopy(data,0,txData,0,len);
                    Log.d(TAG,"printer send:"+txData.length);
                    sendPrinterData(txData);
                }else{
                    break;
                }
            }
        }
    }
    private List<BluetoothDevice> lastBtDevices=new ArrayList<BluetoothDevice>();
    private void taskFindBtDevice(){
        Handler handler_find_bt=new Handler();
        Runnable runnable_find_bt=new Runnable() {
            @SuppressLint("MissingPermission")
            @Override
            public void run() {
                List<BluetoothDevice> devices=findBtConnectedDevices();
                if(lastBtDevices.size()!=devices.size()){
                    if(devices.size()>0){
                        bleDevice=devices.get(0);
                        bleDevice.connectGatt(service,false,mGattCallback);
                    }else {
                        show_disconnected();
                    }
                }
                lastBtDevices=devices;
                handler_find_bt.postDelayed(this,3000);
            }
        };
        handler_find_bt.postDelayed(runnable_find_bt,500);
    }
    @SuppressLint("MissingPermission")
    private List<BluetoothDevice> findBtConnectedDevices(){
        List<BluetoothDevice> connectedDevices=new ArrayList<BluetoothDevice>();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            BluetoothManager bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            List<BluetoothDevice> devices = bluetoothManager.getConnectedDevices(BluetoothProfile.GATT);
            for(BluetoothDevice device:devices){
                if(device.getBluetoothClass().toString().equals("580")){
                    connectedDevices.add(device);
                }
            }
        }else{
            BluetoothManager bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            BluetoothAdapter bluetoothAdapter = bluetoothManager.getAdapter();
            Class<BluetoothAdapter> bluetoothAdapterClass = BluetoothAdapter.class;
            Method method = null;
            try {method = bluetoothAdapterClass.getDeclaredMethod("getConnectionState", (Class[]) null);} catch (NoSuchMethodException e) {}
            method.setAccessible(true);
            int state = 0;
            try {state = (int) method.invoke(bluetoothAdapter, (Object[]) null);} catch (IllegalAccessException e) {} catch (
                    InvocationTargetException e) {}
            if (state == BluetoothAdapter.STATE_CONNECTED) {
                Set<BluetoothDevice> bondedDevices = bluetoothAdapter.getBondedDevices();
                //Log.d(TAG, "bondedDevices:" + bondedDevices.size());
                for (BluetoothDevice device : bondedDevices) {
                    Method isConnectedMethod = null;
                    try {
                        isConnectedMethod = BluetoothDevice.class.getDeclaredMethod("isConnected", (Class[]) null);
                    } catch (NoSuchMethodException e) {
                    }
                    method.setAccessible(true);
                    boolean isConnected = false;
                    try {
                        isConnected = (boolean) isConnectedMethod.invoke(device, (Object[]) null);
                    } catch (InvocationTargetException e) {
                    } catch (IllegalAccessException e) {
                    }
                    if (isConnected) {
                        if(device.getBluetoothClass().toString().equals("580")){
                            connectedDevices.add(device);
                        }
                    }
                }
            }
        }
        return connectedDevices;
    }
    private BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {
        @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            if(newState==BluetoothGatt.STATE_CONNECTED){
                Log.d(TAG,"BluetoothGatt.STATE_CONNECTED");
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    gatt.requestMtu(512);
                }
                gatt.discoverServices();
                bluetoothGatt=gatt;
            }else if(newState==BluetoothGatt.STATE_DISCONNECTED){
                Log.d(TAG,"BluetoothGatt.STATE_DISCONNECTED");
                gatt.close();
            }
            super.onConnectionStateChange(gatt, status, newState);
        }
        @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            super.onServicesDiscovered(gatt, status);
            if(status==BluetoothGatt.GATT_SUCCESS){
                for(BluetoothGattService service : gatt.getServices()){
                    for (BluetoothGattCharacteristic characteristic : service.getCharacteristics()) {
                        //Log.d(TAG, "uuid: " + characteristic.getUuid() + " properity: " + characteristic.getProperties());
                        if(characteristic.getUuid().toString().equals("6e400003-b5a3-f393-e0a9-e50e24dcca9e")){
                            scannerRxCharacteristic=characteristic;
                            enableNotifications(gatt,characteristic);
                            if(_ConnectionChangeCallBack!=null)_ConnectionChangeCallBack.callback(bleDevice.getAddress(),bleDevice.getName(),true);
                            show_connected();
                        }
                        if(characteristic.getUuid().toString().equals("0000fff1-0000-1000-8000-00805f9b34fb")){
                            rxCharacteristic=characteristic;
                            enableNotifications(gatt,characteristic);
                        }
                        if(characteristic.getUuid().toString().equals("0000fff2-0000-1000-8000-00805f9b34fb")){
                            txCharacteristic=characteristic;
                            txCharacteristic.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
                            Log.d(TAG,"txCharacteristic="+characteristic.getUuid());
                        }
                    }
                }
            }
        }
        @Override
        public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
            super.onMtuChanged(gatt, mtu, status);
            if (status == BluetoothGatt.GATT_SUCCESS) {
                mtu_size = mtu - 3;
                Log.d(TAG, "mtu_size: " + mtu_size);
            }
        }
        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            super.onCharacteristicChanged(gatt, characteristic);
            //Log.d(TAG,"onCharacteristicChanged uuid:"+characteristic.getUuid()+" size:"+characteristic.getValue().length);
            if(scannerRxCharacteristic.getUuid().equals(characteristic.getUuid())) {
                String scan_data=new String(characteristic.getValue());
                Log.d(TAG,"scan_data:["+scan_data+"] len:"+scan_data.length());
                if(_ScanDataCallBack!=null)_ScanDataCallBack.callback(bleDevice.getAddress(),bleDevice.getName(),scan_data);
            }
            if(rxCharacteristic.getUuid().equals(characteristic.getUuid())) {
                byte[] rxData=characteristic.getValue();
                Log.d(TAG,"onPrinterRxCallback len:"+rxData.length);
                if(localSocket!=null){
                    byte[] data=rxData;
                    int len=data.length;
                    Log.d(TAG,"printer rx len:"+len);
                    boolean already_handled=false;
                    if(len==6){
                        if(data[0]==0x1D&&data[1]==(byte)0x9A&&data[5]==(byte)0xFF){
                            already_handled=true;
                            int page_remain=data[2+0] & 0xFF | (data[2+1] & 0xFF) << 8;
                            int paper_exist=data[4];
                            Log.d(TAG,"prn_page_status_report: page_remain="+page_remain+" paper_exist="+paper_exist);
                            //PrinterService.show_page_remain_status(page_remain,paper_exist);
                        }else if(data[0]==0x1D&&data[1]==(byte)0x9E&&data[5]==(byte)0xFF){
                            byte step=data[2];
                            int  time_stamp=(data[3]&0xFF)+(data[4]&0xFF)*256;
                            String stepStr="unkown";
                            if(step==0x20)stepStr="render_start";
                            if(step==0x30)stepStr="print_start";
                            if(step==0x40)stepStr="goto_mark_start";
                            if(step==0x50)stepStr="print_stop";
                            if(step==0x60)stepStr="engine_stop";
                            Log.d(TAG,"prn_status_report:"+stepStr+" time_stamp:"+time_stamp);
                        }
                    }
                    if(!already_handled){
                        try {
                            localSocket.getOutputStream().write(data,0,len);
                        } catch (IOException e) {
                            //e.printStackTrace();
                        }
                    }
                }
            }
        }
    };
    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    public void enableNotifications(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
        if (gatt == null || characteristic == null) return;
        //bluetoothGatt.setCharacteristicNotification(characteristic, false);
        bluetoothGatt.setCharacteristicNotification(characteristic, true);
        /*
        for(BluetoothGattDescriptor dp: characteristic.getDescriptors()){
            if (dp != null) {
                if ((characteristic.getProperties() & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0) {
                    dp.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                } else if ((characteristic.getProperties() & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) {
                    dp.setValue(BluetoothGattDescriptor.ENABLE_INDICATION_VALUE);
                }
                gatt.writeDescriptor(dp);
            }
        }
         */
    }
    private List<byte[]> splitSendData(byte[] data, int mtu) {
        List<byte[]> packets = new ArrayList<>();
        int offset = 0;

        while (offset < data.length) {
            int length = Math.min(mtu, data.length - offset);
            byte[] packet = new byte[length];
            System.arraycopy(data, offset, packet, 0, length);
            packets.add(packet);
            offset += length;
        }
        return packets;
    }
    @SuppressLint("MissingPermission")
    public void sendPrinterData(byte[] data) {
        List<byte[]> packets = splitSendData(data,mtu_size);
        Log.d(TAG,"packets size:"+packets.size());
        for (byte[] packet : packets) {
            txCharacteristic.setValue(packet);
            boolean success = bluetoothGatt.writeCharacteristic(txCharacteristic);
            Log.d(TAG,"txCharacteristic("+txCharacteristic.getUuid()+"):"+packet.length+" success:"+success);
            try {Thread.sleep(100);} catch (InterruptedException e) {}
        }
    }
}
