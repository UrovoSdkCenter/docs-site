﻿K388Pro BLE SDK v1.0.0

Contents:
1. docs\                                 Offline HTML documentation
2. UK388PrintBleLibrary_fat_v1.0.0.jar   SDK
3. BtScanPrintDemo-1.0.zip               Demo project
4. open-docs.bat                         Double-click to open docs

How to use:
1. Unzip this archive.
2. Double-click open-docs.bat. The browser will open the docs.
3. Close the console window to stop the local server.
4. Put the JAR into your app module libs folder.
5. Unzip BtScanPrintDemo-1.0.zip and open it in Android Studio.

Do not double-click docs\index.html directly (some browsers block local scripts).